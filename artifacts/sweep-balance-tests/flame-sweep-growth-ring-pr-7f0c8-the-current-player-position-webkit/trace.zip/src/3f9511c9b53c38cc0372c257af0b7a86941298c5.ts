import { test, expect } from '@playwright/test';
import { Combat } from '../src/combat';
import { PartySystem } from '../src/party';
import { FLAME_SWEEP, flameSweepStats, insideSweep } from '../src/flame-sweep';
import { RunFlow } from '../src/run-flow';

const origin = { x: 0, z: 0 };
function fixture(level = 5) {
  const c = new Combat([], 32, () => .25); c.party = new PartySystem(); c.fusionEnabled = true;
  c.automaticSpawning = false; c.reset();
  for (let i=0; i<level; i++) expect(c.grantUpgrade('flame-sweep-weapon')).toBe(true);
  c.runBuild.attacks[0].cooldown = 1000; c.runBuild.attacks[1].cooldown = 1000;
  c.invulnerability = 1000;
  return c;
}
function tick(c: Combat, dt = 1/60) { c.party!.syncLeader(origin, 0); c.update(dt, origin); }

test('upgrades grow actual range and angle, and cap relic/range stacking at close range', () => {
  const first = flameSweepStats(1), last = flameSweepStats(5);
  const angle = 135*Math.PI/180, x = Math.cos(angle)*3.8, z = Math.sin(angle)*3.8;
  expect(insideSweep(x,z,1,0,first.radius,.1,first.angle)).toBe(false);
  expect(insideSweep(x,z,1,0,last.radius,.1,last.angle)).toBe(true);
  expect(insideSweep(-3.8,0,1,0,last.radius,.1,last.angle)).toBe(false);
  expect(flameSweepStats(3).ringInterval).toBe(0);
  expect(flameSweepStats(4).ringInterval).toBe(5);
  expect(last.ringInterval).toBe(4);
  const c=fixture(); for(let i=0;i<5;i++)c.grantUpgrade('range');
  expect(c.grantUpgrade('overload-core')).toBe(true);
  const profile=flameSweepStats(5,c.stats.rangeMultiplier,c.runBuild.rules('flame-sweep').areaMultiplier);
  expect(profile.radius).toBe(6); expect(profile.ringRadius).toBe(6.5);
});

test('periodic fire ring hits all directions once even with a saturated bolt pool and no sweep', () => {
  const c=fixture();
  for (const p of c.projectiles) Object.assign(p,{active:true,x:20,z:20,previousX:20,previousZ:20,vx:0,vz:0,life:100,damage:0});
  const victims = [[-4,0],[4,0],[0,4],[0,-4]].map(([x,z])=>c.spawn('tank',x,z,0)!);
  tick(c); expect(c.flameRing.pulseId).toBe(0);
  for(let i=0;i<237;i++)tick(c);
  for(const e of victims)expect(e.hp).toBe(100);
  tick(c);tick(c); // Four full seconds; the ring runs without a sweep target gate.
  expect(c.flameRing.pulseId).toBe(1);
  for(const e of victims)expect(e.hp).toBeCloseTo(100-36*1.8*.45);
  expect(c.flameRing.hitIds.filter(Boolean)).toHaveLength(4);
  const health = victims.map(e=>e.hp);tick(c,.1);expect(victims.map(e=>e.hp)).toEqual(health);
  expect(c.melee.attackInstanceId).toBe(0); expect(c.shotsFired).toBe(0);
});

test('ring protects walls and spawn warnings; its unlocked area follows the current player position', () => {
  const c=fixture(); tick(c);
  c.flameRing.cooldown = 0;
  const covered=c.spawn('tank',12,0,0)!, warned=c.spawn('tank',10,1,1)!;
  const hit=c.spawn('tank',8,0,0)!;
  c.setObstacles([{x:11,z:0,radius:.4}]);
  const player={x:10,z:0}; c.party!.syncLeader(player,0);c.update(1/60,player);
  expect(c.flameRing.x).toBe(10);expect(hit.hp).toBeLessThan(100);
  expect(covered.hp).toBe(100);expect(warned.hp).toBe(100);
});

test('ring timing pauses for upgrades and death, clears on wave boundaries and resets on restart', () => {
  const c=fixture();tick(c); const before=JSON.stringify(c.flameRing);
  c.progression.gainExperience(8);tick(c,.5);expect(JSON.stringify(c.flameRing)).toBe(before);
  c.chooseUpgrade(c.progression.offers[0]);c.hp=0;
  const dead=JSON.stringify(c.flameRing);tick(c,.5);expect(JSON.stringify(c.flameRing)).toBe(dead);
  c.hp=100;c.clearWave();expect(c.flameRing.active).toBe(false);expect(c.flameRing.armed).toBe(false);
  tick(c);expect(c.flameRing.cooldown).toBeGreaterThan(3);expect(c.flameRing.active).toBe(false);
  c.reset();expect(c.flameRing.pulseId).toBe(0);expect(c.flameRing.armed).toBe(false);
});

test('upgrading level four to five preserves ring cooldown progress and exposes the next reward', () => {
  const c=fixture(3);
  expect(c.progression.skills.find(s=>s.id==='flame-sweep-weapon')!.description).toContain('解锁环形火焰');
  c.grantUpgrade('flame-sweep-weapon');tick(c);
  c.flameRing.cooldown=2.5;
  expect(c.progression.skills.find(s=>s.id==='flame-sweep-weapon')!.description).toContain('强化环形火焰');
  c.grantUpgrade('flame-sweep-weapon');expect(c.flameRing.cooldown).toBeCloseTo(2);
  c.grantUpgrade('haste');expect(c.flameRing.cooldown).toBeLessThan(2);
});

test('elite and boss resistance preserves remote single-target roles; ring respects Boss death gating', () => {
  const c=fixture();tick(c);c.flameRing.cooldown=0;
  const normal=c.spawn('tank',-2,0,0)!, elite=c.spawn('tank',2,0,0)!;elite.rank='elite';
  tick(c);expect(100-elite.hp).toBeCloseTo((100-normal.hp)*FLAME_SWEEP.eliteMultiplier);
  const bossCombat=fixture(),run=new RunFlow();run.waveIndex=5;run.prepare(bossCombat,origin);
  const boss=bossCombat.encounters.boss!;Object.assign(boss,{x:-2,z:0,previousX:-2,previousZ:0,hp:1,spawnTime:0});
  tick(bossCombat);bossCombat.flameRing.cooldown=0;tick(bossCombat);
  expect(bossCombat.encounters.dying).toBe(true);expect(bossCombat.flameRing.active).toBe(false);
  run.update(1/60,bossCombat,origin);expect(run.phase).toBe('fighting');
  bossCombat.encounters.beforeTick(1);run.update(1/60,bossCombat,origin);expect(run.phase).toBe('won');
});
