import { test, expect, type Page } from '@playwright/test';

async function open(page:Page,missing=false){
  await page.setViewportSize({width:844,height:390});
  if(missing){
    await page.route('**/flame-sweep/flame-sweep.png',route=>route.abort());
    await page.route('**/yanrong/fire-effects-sheet.normalized.png',route=>route.abort());
    await page.route('**/particles/kenney-feedback.png',route=>route.abort());
  }
  await page.route('**/sweep-effects-harness*',route=>route.fulfill({contentType:'text/html; charset=utf-8',body:`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body><div id="app"></div><script type="module">
    import '/src/style.css';import {createUI} from '/src/ui.ts';import {Game} from '/src/game.ts';
    createUI(document.getElementById('app'));const g=window.game=new Game();
    window.draw=()=>{g.sleep();g.placeCamera(true);g.partyView.render(1,g.visualTime);g.combatView.render(1,g.visualTime,g.position);g.updateHUD();g.renderer.render(g.scene,g.camera)};
    window.pose=(sweepAge,ringAge)=>{g.sleep();g.combat.melee.active=true;g.combat.flameRing.active=true;g.combat.melee.age=sweepAge;g.combat.flameRing.age=ringAge;window.draw();return g.combatView.inspect().melee};
    window.arrange=()=>{
      g.sleep();const c=g.combat;c.clearWave();c.obstacles=[];c.useNavigation=false;c.automaticSpawning=false;c.invulnerability=1000;
      for(let i=0;i<4;i++)c.grantUpgrade('flame-sweep-weapon');
      g.position.set(0,0,0);g.party.syncLeader(g.position,0);
      for(const a of c.runBuild.attacks)a.cooldown=a.attackId==='flame-sweep'?0:1000;
      for(const [x,z] of [[2,0],[3.2,1.8],[3.2,-1.8],[.5,3.7],[.5,-3.7],[-3.5,0]]){
        const e=c.spawn('normal',x,z,0);e.hp=500;
      }
      c.update(1/60,g.position);c.flameRing.cooldown=0;c.update(1/60,g.position);
      document.getElementById('welcome').hidden=true;window.pose(.13,.18);
    };
  </script></body></html>`}));
  await page.goto('/sweep-effects-harness?world=fixed&meleeDev=flame-sweep');
  await page.locator('#start-fusion').click();
  await page.evaluate(()=>(window as any).game.sleep());
  await expect.poll(()=>page.evaluate(missing=>{
    const v=(window as any).game.combatView.inspect().melee;
    return missing?v?.failed&&v.assets.fire.failed&&v.assets.particles.failed:v?.loaded&&v.assets.fire.loaded&&v.assets.particles.loaded;
  },missing)).toBe(true);
  await page.evaluate(()=>(window as any).arrange());
}

test('fire ring stays clean with sparse point sparks and no upright flame or trace particles',async({page,browserName})=>{
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  page.on('console',m=>{if(m.type()==='error'&&/WebGL|shader|GL_INVALID/i.test(m.text()))errors.push(m.text())});
  await open(page);
  for(const [age,frame] of [[.03,12],[.1,13],[.2,14]]){
    const result=await page.evaluate(({age})=>{
      const w=window as any,g=w.game;w.pose(.13,age);
      const before=JSON.stringify(g.combat.inspect());w.draw();
      return {view:g.combatView.inspect().melee,unchanged:before===JSON.stringify(g.combat.inspect())};
    },{age});
    expect(result.unchanged).toBe(true);expect(result.view.assets.ringFrame).toBe(frame);
    expect(result.view.assets.fire.frames).toContain(frame);
    expect(result.view.assets.particles.frames.every((frame:number)=>frame===1)).toBe(true);
    expect(result.view.assets.sweepSparks).toBeLessThanOrEqual(5);expect(result.view.assets.ringSparks).toBe(6);
    expect(result.view.assets.particles.count).toBeGreaterThan(0);
    expect(result.view.assets.embers).toBeLessThanOrEqual(11);
    expect(new Set(result.view.assets.particles.alpha).size).toBeGreaterThan(4);
    for(const batch of [result.view.assets.fire,result.view.assets.particles]){
      expect(batch.count).toBeLessThanOrEqual(batch.capacity);
      expect(batch.alpha.every((alpha:number)=>alpha>0&&alpha<=1)).toBe(true);
    }
    if(browserName==='chromium')await page.screenshot({path:`artifacts/flame-effects-phase-${frame}.png`});
  }
  const changed=await page.evaluate(()=>{
    const w=window as any,g=w.game;w.pose(.13,.18);
    const gl=g.renderer.getContext(),count=gl.drawingBufferWidth*gl.drawingBufferHeight*4;
    const a=new Uint8Array(count),b=new Uint8Array(count);
    const assets=g.combatView.flameSweep.assets.group;
    gl.readPixels(0,0,gl.drawingBufferWidth,gl.drawingBufferHeight,gl.RGBA,gl.UNSIGNED_BYTE,a);
    const withCalls=g.renderer.info.render.calls;
    assets.visible=false;g.renderer.render(g.scene,g.camera);const withoutCalls=g.renderer.info.render.calls;
    gl.readPixels(0,0,gl.drawingBufferWidth,gl.drawingBufferHeight,gl.RGBA,gl.UNSIGNED_BYTE,b);
    assets.visible=true;w.draw();let changed=0;
    for(let i=0;i<count;i+=4)if(a[i]!==b[i]||a[i+1]!==b[i+1]||a[i+2]!==b[i+2])changed++;
    return {pixels:changed,extraCalls:withCalls-withoutCalls};
  });
  expect(changed.pixels).toBeGreaterThan(150);
  expect(changed.extraCalls).toBeGreaterThan(0);expect(changed.extraCalls).toBeLessThanOrEqual(2);
  for(const width of [844,568]){
    await page.setViewportSize({width,height:width===844?390:320});
    await page.evaluate(()=>(window as any).pose(.13,.18));
    if(browserName==='chromium')await page.screenshot({path:`artifacts/flame-effects-upgraded-${width}.png`});
  }
  expect(errors).toEqual([]);
});

test('atlas layers are reusable, pause with combat and clear on restart',async({page})=>{
  await open(page);
  const stable=await page.evaluate(()=>{
    const w=window as any,g=w.game;w.pose(.13,.18);
    const before=JSON.stringify(g.combat.inspect()),memory={...g.renderer.info.memory},assets=g.combatView.flameSweep.assets;
    for(let i=0;i<100;i++)w.draw();
    return {same:before===JSON.stringify(g.combat.inspect()),memoryStable:JSON.stringify(memory)===JSON.stringify(g.renderer.info.memory),sameAssets:assets===g.combatView.flameSweep.assets};
  });
  expect(stable).toEqual({same:true,memoryStable:true,sameAssets:true});
  await page.locator('#pause').click();
  const before=await page.evaluate(()=>JSON.stringify((window as any).game.combat.inspect()));
  await page.evaluate(()=>{const g=(window as any).game;for(let i=0;i<120;i++)g.step(1/60)});
  expect(await page.evaluate(()=>JSON.stringify((window as any).game.combat.inspect()))).toBe(before);
  await page.locator('#restart').click();
  const reset=await page.evaluate(()=>{const w=window as any;w.game.sleep();w.draw();return w.game.combatView.inspect().melee.assets});
  expect(reset.fire.count).toBe(0);expect(reset.particles.count).toBe(0);
});

test('missing all three atlases preserves procedural fallback and real melee and ring hits',async({page})=>{
  await open(page,true);
  const result=await page.evaluate(()=>{const g=(window as any).game;return {view:g.combatView.inspect().melee,hits:g.combat.hits,shots:g.combat.shotsFired}});
  expect(result.hits).toBeGreaterThan(6);expect(result.shots).toBe(0);
  expect(result.view.fallback).toBe(true);expect(result.view.ring.fallback).toBe(true);
  expect(result.view.assets.fire.count).toBe(0);expect(result.view.assets.particles.count).toBe(0);
});
